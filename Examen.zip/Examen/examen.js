function cart() {
    alert("Your Cart is Empy!")
}

function mouse_dentro(elemento_imagen) {
    elemento_imagen.src = "assets/succulents-2.jpg";
}

function mouse_fuera(elemento_imagen) {
    elemento_imagen.src = "assets/succulents-1.jpg";
}

function eliminar_cookies() {
    var elemento_cookie = document.querySelector(".cookies");
    elemento_cookie.remove();
}